import React, { useEffect, useState } from 'react';
import Polygon1 from '../../assets/images/Polygon 1.svg';
import Polygon2 from '../../assets/images/Polygon 2.svg';
import date_time from '../../assets/images/date_time.svg';
import language from '../../assets/images/language.svg';
import experience_icon from '../../assets/images/experience_icon.svg';
import expertiseicon from '../../assets/images/expertise-icon.svg';
import globeVar from '../../GlobeApi';
import axios from "axios";

const Dashboard = () => {
    //search functionaly
    const [searchTerm, setSearchTerm] = useState("");
    const inputEvent = (event) => {
        const data =  event.target.value;
        console.log(data);
        setSearchTerm(data);
    }

    const [bookInfo,setBookInfo] = useState([])
        const booked = () => {
            //api call of appointments
                    axios.post( globeVar +"users").then((response)=>{
                        if(response.data.success === 1)
                        {
                             var myArray = response.data.data;
                            
                            console.log(myArray);
                            setBookInfo(myArray);
                        }
                     }) 
            }
    useEffect(() => {
        booked();
      },[])
   
  return (
    <div><section className="mb-4 mb-md-5">
    <div className="container pb-0 section-padding">
    
    <div className="">
        <div className="align-items-center row">
            <h3 className="col mb--4 mb-md-0 title">My Dashboard</h3>
            
        </div>
    </div>
    </div>
    </section>
    </div>
  )
}

export default Dashboard;