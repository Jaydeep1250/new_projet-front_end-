
import React, {useState, useEffect} from 'react';
import globeVar from '../../GlobeApi';
import './DashboardNav.css'
import axios from "axios";
/* import { useParams } from "react-router-dom"; */
import logo from '../../assets/images/logo.png';
import profile_fill from '../../assets/images/profile_fill.svg';
import profile from '../../assets/images/profile.svg';
import support_fill from '../../assets/images/support_fill.svg';
import logout from '../../assets/images/logout.svg';
import $ from 'jquery';
import Swal from 'sweetalert2';


const DashboardNav = () => {
  let data = sessionStorage.getItem('user');
    data = JSON.parse(data);
    const str = data.first_name;
  
   /*  const str1 = str.split("@"); */
    /* console.log(data.email); */
    setTimeout(()=> {
      signOut();
    }, 3600000);
    
    const signOut = () =>{
      $(".logout").trigger('click');
      localStorage.clear();
      sessionStorage.clear();
   
      window.location.href = '/';
    }

  const handleLogout = async (e) => {
    e.preventDefault();
    /* let data = sessionStorage.getItem('user');
    data = JSON.parse(data);
    console.log(data.email); */
    Swal.fire({
      title: 'Are you sure, do you want to log out?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes'
    }).then((result) => {

      if (result.isConfirmed) {
        $(".logout").trigger('click');
    localStorage.clear();
    sessionStorage.clear();
 
    window.location.href = '/'
      }
    })
    
   
  };

  const forced_logout = () => {
    const user_id = data.id;
    
    let item = { "user_id":user_id}; 
    axios.post( globeVar+"f_logout",item).then((response)=>{
   
      if(response.data.success === 1)
    {
      if(response.data.data){
        if(response.data.data.status === "0"){
          $(".logout").trigger('click');
          localStorage.clear();
          sessionStorage.clear();
       
          window.location.href = '/';
        }
      }else{
        $(".logout").trigger('click');
      localStorage.clear();
      sessionStorage.clear();
   
      window.location.href = '/';
      }
     
    }else{
    
      $(".logout").trigger('click');
      localStorage.clear();
      sessionStorage.clear();
   
      window.location.href = '/';
    }

   
    }) 
  
} 
  /* const [word, setWord] = useState([]);
  const [word1, setWord1] = useState([]);
  const [word2, setWord2] = useState([]);
 
   const defineWord = () => {
     //api of therapist
     fetch(globeVar + "ip/send")
       .then((response) => response.json())
       .then((data) => {
         console.log(data);
         setWord(data.data);
     setWord1(data.data1)
     setWord2(data.data2)
         console.log(data.data);
       })
       .catch((error) => {
         console.log(error);
       });
   }; */
   const [timezone, setTimezone] = useState([]);
 /*  const [word1, setWord1] = useState([]);
  const [word2, setWord2] = useState([]); */
 
   const defineWord = () => {
     //api of therapist
     fetch(globeVar + "timezone")
       .then((response) => response.json())
       .then((data) => {
         console.log(data.data);
         setTimezone(data.data);
    
       })
       .catch((error) => {
         console.log(error);
       });
   };
  const change_timezone = (event) => {
    const user_id = data.id;
    const timezone = event.target.value;
    
    let item = { "user_id":user_id, "timezone":timezone}; 
    axios.post( globeVar+"/therapist/schedule_list/get_schedule_by_date",item).then((response)=>{

    });
  }
  useEffect(() => {
    forced_logout();
    defineWord();
}, []) 
  return (
  
    <div><header className=" sticky-top dashboard-header">
    <nav className="container navbar navbar-expand-lg navbar-light">
   <a className="navbar-brand" href="/">
       <img src={logo} alt="ShivYog" />
   </a>
   <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
     <span className="navbar-toggler-icon"></span>
   </button>
 
  
   <div className="ml-auto">
   <ul className="navbar-nav ">
     
   <li className="nav-item dropdown user-dropdown">
       <a className="nav-link m-0" href="javascript:void(0)" id="howWorksDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
       <img src={profile_fill} alt="" className="usen-img" /><span className="user-name">{str}</span> <i className="fa fa-angle-down" ></i></a>

       <div className="dropdown-menu dropdown-menu-right" aria-labelledby="howWorksDropdown">
                       <div className="dropdown-box">
                           <a className="dropdown-item" href="manageaccount" onClick={forced_logout}><span className="dpdwn-icons"><img src={profile} alt="" /></span> Manage Profile</a>
                           <a className="dropdown-item" href="contactsupport"><span className="dpdwn-icons"><img src={support_fill} alt="" /></span>Contact Support</a>
                           <a className="dropdown-item"  id='lgout' href="/" onClick={handleLogout} ><span className="dpdwn-icons"><img src={logout} alt="" /></span>Logout </a>
              
                       </div>
                   </div>
     </li>
   </ul>
   </div>
 </nav>

    </header></div>
  )
}

/* $(document).ready(function(){
  
  var intials = fname.charAt(0) + lname.charAt(0);
  var profileImage = $('#profileImage').text(intials);
}); */
export default DashboardNav;