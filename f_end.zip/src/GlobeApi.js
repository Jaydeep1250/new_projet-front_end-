const globeVar = "http://localhost:2000/api/";
export default globeVar;